<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm dữ liệu vào bảng</title>
</head>
<body>

<h2>Bấm vào nút để thêm 5 người vào bảng</h2>

<!-- Form có nút bấm -->
<form method="post">
    <button type="submit" name="insert_data">Thêm dữ liệu</button>
</form>
<?php
// Kiểm tra nếu nút bấm được bấm
if (isset($_POST['insert_data'])) {
    $host = "sql110.infinityfree.com";
    $db_name = "if0_37096559_dbweb";
    $username = "if0_37096559";
    $password = "phuong12021995";
    $table_name = "myGuests";

    $conn = new mysqli($host, $username, $password,$db_name);
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Mảng chứa dữ liệu của 5 người
    $data_array = [
        ['first_name' => 'John', 'last_name' => 'Doe', 'email' => 'john@example.com'],
        ['first_name' => 'Jane', 'last_name' => 'Smith', 'email' => 'jane@example.com'],
        ['first_name' => 'James', 'last_name' => 'Johnson', 'email' => 'james@example.com'],
        ['first_name' => 'Emily', 'last_name' => 'Brown', 'email' => 'emily@example.com'],
        ['first_name' => 'Michael', 'last_name' => 'Davis', 'email' => 'tom@example.com'],
    ];

    $sql="INSERT INTO $table_name (first_name, last_name, email) VALUES (?,?,?)";
    $stmt=$conn->prepare($sql);
    if ($stmt === FALSE) {
      die("Error preparing statement: " . $conn->error);
    }

    foreach ($data_array as $data) {
      $stmt->bind_param("sss", $data['first_name'], $data['last_name'], $data['email']);

      if ($stmt->execute() === TRUE) {
          echo "Record for {$data['first_name']} {$data['last_name']} inserted successfully.<br>";
      } else {
          echo "Error inserting record for {$data['first_name']} {$data['last_name']}: " . $stmt->error . "<br>";
      }
  }

  $stmt->close();
  $conn->close();
    echo "<p>Hoàn tất việc thêm dữ liệu!</p>";
}
?>
<br>
<a href="view.php">Xem dữ liệu trong bảng</a>

</body>
</html>
